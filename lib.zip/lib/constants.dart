import 'package:flutter/material.dart';

const kPrimaryColor = Color(0xFF2D0C40);
const kPrimaryLightColor = Color(0xFF8B5CBD);
